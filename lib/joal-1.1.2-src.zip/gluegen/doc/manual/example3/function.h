/* Give GlueGen a typedef for size_t */
typedef int size_t;

size_t strlen(const char* str);
char*  strstr(const char* str1, const char* str2);
